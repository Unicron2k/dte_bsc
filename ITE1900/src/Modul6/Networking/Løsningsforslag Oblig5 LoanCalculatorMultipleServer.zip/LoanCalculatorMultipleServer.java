package Modul06;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;

/**
 * <h1>LoanCalculatorSingleServer class.</h1>
 * <br>
 * This class is the networking server that utilizes {@link ServerSocket} class to connect with clients and communicate with them.
 *
 * @author Daniel Aaron Salwerowicz
 * @version 1.0
 * @since 2018-04-16
 */
public class LoanCalculatorMultipleServer extends Application {
  /**
   * Text area for displaying contents
   */
  private TextArea ta = new TextArea();

  /**
   * Counter for number of clients connected to this server
   */
  private int clientNo = 1;

  /**
   * Start method that sets up background processes and displays primary stage with GUI
   */
  @Override
  public void start(Stage primaryStage) {
    ta.setWrapText(true);

    // Create a scene and place it in the stage
    Scene scene = new Scene(ta, 600, 200);
    primaryStage.setTitle("Loan Calculator, Server"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage

    new Thread(this::connectToClient).start();
  }

  /**
   * Waits for clients to connect with it and then creates an instance of {@link HandleAClient} to communicate with client
   *
   * @see Loan
   */
  private void connectToClient() {
    try {
      // Create a server socket
      ServerSocket serverSocket = new ServerSocket(8000);
      writeToLog("Server started at " + new Date());

      while (true) {
        // Listen for a new connection request
        Socket connectToClient = serverSocket.accept();

        final int number = clientNo;
        // Display the client number
        writeToLog("\nStarting thread for client " + number + " at " + new Date());

        // Find the client's host name, and IP address
        InetAddress clientInetAddress = connectToClient.getInetAddress();
        writeToLog("Client " + number + "'s host name is " + clientInetAddress.getHostName());
        writeToLog("Client " + number + "'s IP Address is " + clientInetAddress.getHostAddress() + "\n");

        // Create a new thread for the connection
        new HandleAClient(connectToClient).start();

        // Increment clientNo
        clientNo++;
      }
    } catch (IOException ex) {
      writeToLog('\n' + ex.toString());
    }
  }

  /**
   * <h1>LoanCalculatorSingleServer class.</h1>
   * <br>
   * This class extends {@link Thread} class and handles a client
   *
   * @author Daniel Aaron Salwerowicz
   * @version 1.0
   * @since 2018-04-16
   */
  class HandleAClient extends Thread {
    /**
     * {@link Socket} used to connect with client and communicate with him
     */
    private Socket connectToClient;

    /**
     * Construct a new thread
     *
     * @param socket Client socket
     */
    public HandleAClient(Socket socket) {
      connectToClient = socket;
    }

    /**
     * Run a thread that communicates with client and calculates monthly and yearly payment on loan for him
     */
    public void run() {
      try {
        // Create data input and output streams
        DataInputStream isFromClient = new DataInputStream(connectToClient.getInputStream());
        DataOutputStream osToClient = new DataOutputStream(connectToClient.getOutputStream());

        // Continuously serve the client
        while (true) {
          // Receive annual interest rate from the client
          double annualInterestRate = isFromClient.readDouble();

          // Receive number of years f6hhurom the client
          int numOfYears = isFromClient.readInt();

          // Receive loan from the client
          double loanAmount = isFromClient.readDouble();

          // Compute monthly payment and total payment
          Loan mortgage = new Loan(annualInterestRate, numOfYears, loanAmount);
          double monthlyPayment = mortgage.getMonthlyPayment();
          double totalPayment = mortgage.getTotalPayment();

          // Send results back to the client
          osToClient.writeDouble(monthlyPayment);
          osToClient.writeDouble(totalPayment);

          writeToLog(String.format(
              "Annual Interest rate: \t%.2f %nNumber of years: \t\t%d %nLoan amount:\t\t\t%.2f",
              annualInterestRate,
              numOfYears,
              loanAmount));

          // Print payment info
          writeToLog(String.format(
              "Monthly payment: \t\t%5.2f %nTotal payment: \t\t%5.2f %n",
              monthlyPayment,
              totalPayment));
        }
      } catch (IOException ex) {
        writeToLog('\n' + ex.toString());
      }
    }
  }

  /**
   * Uses {@link Platform#runLater(Runnable)} method to update {@link TextArea} with a given message
   *
   * @param message Message to be displayed in TextArea
   */
  private void writeToLog(String message) {
    Platform.runLater(() -> ta.appendText(message + '\n'));
  }

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
}
