package Modul06;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import static Test.Helper.*;

/**
 * <h1>LoanCalculatorClient class.</h1>
 * <br>
 * This class is the networking client that utilizes {@link Socket} class to connect with server that calculates monthly and total payments for a loan.
 *
 * @author Daniel Aaron Salwerowicz
 * @version 1.0
 * @since 2018-04-16
 */
public class LoanCalculatorClient extends Application {
  /**
   * {@link TextField} for annual interest rate input
   */
  private TextField tfAnnualInterestRate = new TextField();

  /**
   * {@link TextField} for number of years input
   */
  private TextField tfNumOfYears = new TextField();

  /**
   * {@link TextField} for loan amount input
   */
  private TextField tfLoanAmount = new TextField();

  /**
   * {@link Button} for confirming input
   */
  private Button btSubmit = new Button("Submit");

  /**
   * {@link TextArea} for displaying result
   */
  private TextArea ta = new TextArea();

  /**
   * {@link DataOutputStream} for sending data to server
   */
  private DataOutputStream osToServer;

  /**
   * {@link DataInputStream} for receiving data from server
   */
  private DataInputStream isFromServer;

  /**
   * Start method that sets up background processes and displays primary stage with GUI
   */
  @Override
  public void start(Stage primaryStage) {
    // Enable text wrapping on text area
    ta.setWrapText(true);

    // Initialize text fields
    initializeTextFields();

    // Set in Grid pane with inputs and TextArea wrapped in Scroll pane to final pane
    setUpAndDisplayPrimaryStage(primaryStage);

    // Connect client to server
    connectToServer();

    // Set up button to call appropriate method
    btSubmit.setOnAction(e -> contactServerForResult());
  }

  /**
   * Generates and sets up {@link GridPane} with necessary GUI elements
   *
   * @return {@link GridPane} with input, labels and buttons necessary for this program
   */
  private GridPane getGridPane() {
    GridPane gridPane = new GridPane();
    gridPane.add(new Label("Annual Interest Rate"), 0, 0);
    gridPane.add(new Label("Number Of Years"), 0, 1);
    gridPane.add(new Label("Loan Amount"), 0, 2);
    gridPane.add(tfAnnualInterestRate, 1, 0);
    gridPane.add(tfNumOfYears, 1, 1);
    gridPane.add(tfLoanAmount, 1, 2);
    gridPane.add(btSubmit, 2, 1);

    return gridPane;
  }

  /**
   * Initializes text fields with some design and restrictions
   */
  private void initializeTextFields() {
    tfAnnualInterestRate.setAlignment(Pos.BASELINE_RIGHT);
    tfNumOfYears.setAlignment(Pos.BASELINE_RIGHT);
    tfLoanAmount.setAlignment(Pos.BASELINE_RIGHT);

    tfLoanAmount.setPrefColumnCount(5);
    tfNumOfYears.setPrefColumnCount(5);

    restrictTextFieldInput(tfAnnualInterestRate, POSITIVE_DECIMAL_REGEX);
    restrictTextFieldInput(tfNumOfYears, POSITIVE_INTEGER_REGEX);
    restrictTextFieldInput(tfLoanAmount, POSITIVE_DECIMAL_REGEX);
  }

  /**
   * Sets up primary stage with some design and GridPane
   *
   * @param primaryStage Stage sent in from {@link LoanCalculatorClient#start(Stage)} method
   */
  private void setUpAndDisplayPrimaryStage(Stage primaryStage) {
    BorderPane pane = new BorderPane();
    pane.setCenter(ta);
    pane.setTop(getGridPane());

    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, 375, 200);
    primaryStage.setTitle("Loan Calculator, Client"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
  }

  /**
   * Connect to server and set up {@link LoanCalculatorClient#isFromServer} and {@link LoanCalculatorClient#osToServer}
   */
  private void connectToServer() {
    try {
      // Create a socket to connect to the server
      Socket connection = new Socket("localhost", 8000);

      // Create an input stream to receive data from the server
      isFromServer = new DataInputStream(connection.getInputStream());

      // Create an output stream to send data to the server
      osToServer = new DataOutputStream(connection.getOutputStream());

    } catch (IOException ex) {
      writeToLog('\n' + ex.toString());
    }
  }

  /**
   * Gets data provided by user, sends it to server for calculation and shows result in {@link LoanCalculatorClient#ta}
   */
  private void contactServerForResult() {
    try {
      // Get the annual interest rate from the text field
      double annualInterestRate = getDoubleFromTextField(tfAnnualInterestRate);

      // Get the number of years from the text field
      int numOfYears = getIntegerFromTextField(tfNumOfYears);

      // Get the loan amount from the text field
      double loanAmount = getDoubleFromTextField(tfLoanAmount);

      // Send the annual interest rate to the server
      osToServer.writeDouble(annualInterestRate);

      // Send the number of years to the server
      osToServer.writeInt(numOfYears);

      // Send the loan amount to the server
      osToServer.writeDouble(loanAmount);

      // Force OutputStream to write data right now
      osToServer.flush();

      // Get monthly payment from the server
      double monthlyPayment = isFromServer.readDouble();

      // Get total payment from the server
      double totalPayment = isFromServer.readDouble();

      // Print loan info
      writeToLog(String.format(
          "Annual Interest rate: \t%.2f %nNumber of years: \t\t%d %nLoan amount:\t\t\t%.2f",
          annualInterestRate,
          numOfYears,
          loanAmount));

      // Print payment info
      writeToLog(String.format(
          "Monthly payment: \t\t%5.2f %nTotal payment: \t\t%5.2f %n",
          monthlyPayment,
          totalPayment));

    } catch (IOException ex) {
      writeToLog('\n' + ex.toString());
    }
  }

  /**
   * Uses {@link Platform#runLater(Runnable)} method to update {@link TextArea} with a given message
   *
   * @param message Message to be displayed in TextArea
   */
  private void writeToLog(String message) {
    Platform.runLater(() -> ta.appendText(message + '\n'));
  }

  /**
   * The entry point of application.
   *
   * @param args the input arguments
   */
  public static void main(String[] args) {
    launch(args);
  }
}
