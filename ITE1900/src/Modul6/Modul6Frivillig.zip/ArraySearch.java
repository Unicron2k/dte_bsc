                                     package Modul06                                                                    ;

                       import java . util.concurrent.ExecutorService                                                    ;
                       import java . util.concurrent.Executors                                                          ;
                       import java . util.concurrent.TimeUnit                                                           ;

                                     public class ArraySearch                                                           {
                 private int index = -1                                                                                 ;
                private int number = 1000000                                                                            ;
       private int numberOfThreads = 10                                                                                 ;
               private int[] array = new int[number]                                                                    ;
         private int[] startValues = new int[numberOfThreads]                                                           ;
           private int[] endValues = new int[numberOfThreads]                                                           ;
      private ExecutorService pool = Executors.newCachedThreadPool()                                                    ;

                                     public static void main(String[] args)                                             {
                                     new ArraySearch()                                                                  ;}

                                     public ArraySearch()                                                               {
                                     init()                                                                             ;
                                     runThreads()                                                                       ;

                            System . out.printf("%d is on index %d.%n", number, index)                                  ;}

                                     private void init()                                                                {
                        for (int i = 0; i < array.length; i++)                                                          {
                          array[i] = i + 1                                                                              ;}

                          int size = number / numberOfThreads                                                           ;
                    startValues[0] = 0                                                                                  ;
    endValues[numberOfThreads - 1] = number - 1                                                                         ;

                        for (int i = 0; i < numberOfThreads - 1; i++)                                                   {
                startValues[i + 1] = startValues[i] + size                                                              ;
                      endValues[i] = startValues[i + 1] - 1                                                             ;}}

                                     private void runThreads()                                                          {
                                     try                                                                                {
                        for (int i = 0; i < numberOfThreads && !pool.isShutdown(); i++)                                 {
            ArraySearchTask thread = new ArraySearchTask(startValues[i], endValues[i], number)                          ;
                              pool . execute(thread)                                                                    ;}

                              pool . shutdown()                                                                         ;

                              pool . awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS)                             ;}
                                     catch (InterruptedException e)                                                     {
                            System . out.println(e.getMessage())                                                        ;}}

                                     private synchronized void numberFound(int index)                                   {
                              pool . shutdownNow()                                                                      ;
                              this . index = index                                                                      ;}

                                     private class ArraySearchTask implements Runnable                                  {
                                     private int number                                                                 ;
                                     private int startValue                                                             ;
                                     private int endValue                                                               ;

                                     ArraySearchTask(int startValue, int endValue, int number)                          {
                              this . startValue = startValue                                                            ;
                              this . endValue = endValue                                                                ;
                              this . number = number                                                                    ;}

                                     public void run()                                                                  {
                        for (int i = startValue; i <= endValue; i++)                                                    {
                        if (number == array[i])                                                                         {
                                     numberFound(i)                                                                     ;}}}}}

